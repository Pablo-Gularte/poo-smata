package ar.org.centro8.java.actividad1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ActividadEntregableObligatoria1Application {

	public static void main(String[] args) {
		SpringApplication.run(ActividadEntregableObligatoria1Application.class, args);
	}

}
