package ar.org.centro8.java.actividad1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActividadEntregableObligatoria1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
